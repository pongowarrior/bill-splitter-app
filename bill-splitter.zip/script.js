// Bill Splitter Complete JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const billAmountInput = document.getElementById('billAmount');
    const tipPercentInput = document.getElementById('tipPercent');
    const peopleCountInput = document.getElementById('peopleCount');
    const calculateBtn = document.getElementById('calculateBtn');
    const resultsSection = document.getElementById('resultsSection');
    const totalWithTipSpan = document.getElementById('totalWithTip');
    const perPersonSpan = document.getElementById('perPerson');
    const tipAmountSpan = document.getElementById('tipAmount');
    const shareBtn = document.getElementById('shareBtn');
    const newCalculationBtn = document.getElementById('newCalculationBtn');

    // Advanced/Itemized Elements
    const itemNameInput = document.getElementById('itemName');
    const itemPriceInput = document.getElementById('itemPrice');
    const addItemBtn = document.getElementById('addItemBtn');
    const itemList = document.getElementById('itemList');
    const calculateItemizedBtn = document.getElementById('calculateItemizedBtn');
    const itemizedTipInput = document.getElementById('itemizedTip');
    const itemizedPeopleInput = document.getElementById('itemizedPeople');

    // State Variables
    let currentCalculation = {};
    let calculationHistory = [];
    let itemizedItems = [];
    let isAdvancedMode = false;

    // Initialize App
    function init() {
        loadHistory();
        setupEventListeners();
        billAmountInput.focus();
    }

    // Setup Event Listeners
    function setupEventListeners() {
        // Basic Calculator
        calculateBtn.addEventListener('click', handleBasicCalculation);
        
        // Results Actions
        shareBtn.addEventListener('click', shareResults);
        newCalculationBtn.addEventListener('click', newCalculation);
        
        // Itemized Calculator
        addItemBtn.addEventListener('click', addItem);
        calculateItemizedBtn.addEventListener('click', handleItemizedCalculation);
        
        // Enter key support
        [billAmountInput, tipPercentInput, peopleCountInput].forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') calculateBtn.click();
            });
        });

        [itemNameInput, itemPriceInput].forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') addItemBtn.click();
            });
        });

        [itemizedTipInput, itemizedPeopleInput].forEach(input => {
            input.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') calculateItemizedBtn.click();
            });
        });
    }

    // Basic Calculation Handler
    function handleBasicCalculation() {
        const billAmount = parseFloat(billAmountInput.value);
        const tipPercent = parseFloat(tipPercentInput.value) || 0;
        const peopleCount = parseInt(peopleCountInput.value) || 1;

        // Validation
        if (!billAmount || billAmount <= 0) {
            showAlert('Please enter a valid bill amount', 'error');
            billAmountInput.focus();
            return;
        }

        if (peopleCount <= 0) {
            showAlert('Number of people must be at least 1', 'error');
            peopleCountInput.focus();
            return;
        }

        if (tipPercent < 0) {
            showAlert('Tip percentage cannot be negative', 'error');
            tipPercentInput.focus();
            return;
        }

        // Calculate
        const tipAmount = (billAmount * tipPercent) / 100;
        const totalWithTip = billAmount + tipAmount;
        const perPerson = totalWithTip / peopleCount;

        // Store results
        currentCalculation = {
            type: 'basic',
            billAmount: billAmount,
            tipPercent: tipPercent,
            tipAmount: tipAmount,
            totalWithTip: totalWithTip,
            perPerson: perPerson,
            peopleCount: peopleCount,
            timestamp: new Date().toISOString(),
            items: null
        };

        displayResults();
        saveToHistory();
        showResults();
    }

    // Itemized Calculation Handler
    function handleItemizedCalculation() {
        if (itemizedItems.length === 0) {
            showAlert('Please add some items first', 'error');
            itemNameInput.focus();
            return;
        }

        const tipPercent = parseFloat(itemizedTipInput.value) || 0;
        const peopleCount = parseInt(itemizedPeopleInput.value) || 1;

        if (peopleCount <= 0) {
            showAlert('Number of people must be at least 1', 'error');
            return;
        }

        // Calculate totals
        const subtotal = itemizedItems.reduce((sum, item) => sum + item.price, 0);
        const tipAmount = (subtotal * tipPercent) / 100;
        const totalWithTip = subtotal + tipAmount;
        const perPerson = totalWithTip / peopleCount;

        // Store results
        currentCalculation = {
            type: 'itemized',
            billAmount: subtotal,
            tipPercent: tipPercent,
            tipAmount: tipAmount,
            totalWithTip: totalWithTip,
            perPerson: perPerson,
            peopleCount: peopleCount,
            timestamp: new Date().toISOString(),
            items: [...itemizedItems]
        };

        displayResults();
        saveToHistory();
        showResults();
    }

    // Add Item to Itemized List
    function addItem() {
        const itemName = itemNameInput.value.trim();
        const itemPrice = parseFloat(itemPriceInput.value);

        if (!itemName) {
            showAlert('Please enter an item name', 'error');
            itemNameInput.focus();
            return;
        }

        if (!itemPrice || itemPrice <= 0) {
            showAlert('Please enter a valid item price', 'error');
            itemPriceInput.focus();
            return;
        }

        // Add item
        itemizedItems.push({
            id: Date.now(),
            name: itemName,
            price: itemPrice
        });

        // Update display
        updateItemizedList();
        
        // Clear inputs
        itemNameInput.value = '';
        itemPriceInput.value = '';
        itemNameInput.focus();

        showAlert(`Added "${itemName}" for ${formatCurrency(itemPrice)}`, 'success');
    }

    // Remove Item from Itemized List
    function removeItem(itemId) {
        const itemIndex = itemizedItems.findIndex(item => item.id === itemId);
        if (itemIndex > -1) {
            const removedItem = itemizedItems.splice(itemIndex, 1)[0];
            updateItemizedList();
            showAlert(`Removed "${removedItem.name}"`, 'info');
        }
    }

    // Update Itemized Items Display
    function updateItemizedList() {
        if (itemizedItems.length === 0) {
            itemList.innerHTML = '<p class="no-items">Add items below to split individually</p>';
            return;
        }

        const itemsHtml = itemizedItems.map(item => `
            <div class="item-row">
                <span class="item-name">${escapeHtml(item.name)}</span>
                <span class="item-price">${formatCurrency(item.price)}</span>
                <button onclick="removeItemById(${item.id})" title="Remove item">×</button>
            </div>
        `).join('');

        const total = itemizedItems.reduce((sum, item) => sum + item.price, 0);
        
        itemList.innerHTML = itemsHtml + `
            <div class="total-row">
                <strong>Subtotal: ${formatCurrency(total)}</strong>
            </div>
        `;
    }

    // Global function for removing items (called from onclick)
    window.removeItemById = function(itemId) {
        removeItem(itemId);
    };

    // Display Results
    function displayResults() {
        totalWithTipSpan.textContent = formatCurrency(currentCalculation.totalWithTip);
        perPersonSpan.textContent = formatCurrency(currentCalculation.perPerson);
        tipAmountSpan.textContent = formatCurrency(currentCalculation.tipAmount);
    }

    // Show Results Section
    function showResults() {
        resultsSection.style.display = 'block';
        setTimeout(() => {
            resultsSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }, 100);
    }

    // Share Results
    function shareResults() {
        if (!currentCalculation.billAmount) return;

        let shareText = `💰 Bill Split Results:\n`;
        
        if (currentCalculation.type === 'itemized' && currentCalculation.items) {
            shareText += `📋 Itemized Bill:\n`;
            currentCalculation.items.forEach(item => {
                shareText += `• ${item.name}: ${formatCurrency(item.price)}\n`;
            });
            shareText += `\nSubtotal: ${formatCurrency(currentCalculation.billAmount)}\n`;
        } else {
            shareText += `Total Bill: ${formatCurrency(currentCalculation.billAmount)}\n`;
        }
        
        shareText += `Tip (${currentCalculation.tipPercent}%): ${formatCurrency(currentCalculation.tipAmount)}\n`;
        shareText += `Total with Tip: ${formatCurrency(currentCalculation.totalWithTip)}\n`;
        shareText += `Split ${currentCalculation.peopleCount} ways: ${formatCurrency(currentCalculation.perPerson)} per person\n\n`;
        shareText += `Calculated with Bill Splitter App 📱`;

        // Try native sharing first, then fallback to clipboard
        if (navigator.share) {
            navigator.share({
                title: 'Bill Split Results',
                text: shareText
            }).then(() => {
                showAlert('Results shared successfully!', 'success');
            }).catch(err => {
                console.log('Error sharing:', err);
                fallbackToClipboard(shareText);
            });
        } else {
            fallbackToClipboard(shareText);
        }
    }

    // Fallback to clipboard copying
    function fallbackToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(() => {
                showAlert('Results copied to clipboard!', 'success');
            }).catch(() => {
                legacyClipboardCopy(text);
            });
        } else {
            legacyClipboardCopy(text);
        }
    }

    // Legacy clipboard copy for older browsers
    function legacyClipboardCopy(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.opacity = '0';
        document.body.appendChild(textArea);
        textArea.select();
        
        try {
            document.execCommand('copy');
            showAlert('Results copied to clipboard!', 'success');
        } catch (err) {
            showAlert('Unable to copy results. Please copy manually.', 'error');
            console.log('Copy failed:', err);
        }
        
        document.body.removeChild(textArea);
    }

    // New Calculation
    function newCalculation() {
        // Reset basic inputs
        billAmountInput.value = '';
        tipPercentInput.value = '15';
        peopleCountInput.value = '2';
        
        // Reset itemized inputs
        itemizedTipInput.value = '15';
        itemizedPeopleInput.value = '2';
        itemizedItems = [];
        updateItemizedList();
        itemNameInput.value = '';
        itemPriceInput.value = '';
        
        // Hide results
        resultsSection.style.display = 'none';
        
        // Focus appropriate input based on mode
        if (isAdvancedMode) {
            itemNameInput.focus();
        } else {
            billAmountInput.focus();
        }
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
        
        showAlert('Ready for new calculation!', 'info');
    }

    // Toggle Calculator Mode
    window.toggleCalculatorMode = function() {
        const basicSection = document.getElementById('basicSection');
        const advancedSection = document.getElementById('advancedSection');
        const showAdvancedBtn = document.getElementById('showAdvanced');
        
        isAdvancedMode = !isAdvancedMode;
        
        if (isAdvancedMode) {
            basicSection.style.display = 'none';
            advancedSection.style.display = 'block';
            showAdvancedBtn.style.display = 'none';
            itemNameInput.focus();
        } else {
            basicSection.style.display = 'block';
            advancedSection.style.display = 'none';
            showAdvancedBtn.style.display = 'block';
            billAmountInput.focus();
        }
        
        // Hide results when switching modes
        resultsSection.style.display = 'none';
    };

    // History Management
    function loadHistory() {
        try {
            const saved = localStorage.getItem('billSplitterHistory');
            calculationHistory = saved ? JSON.parse(saved) : [];
        } catch (error) {
            console.error('Error loading history:', error);
            calculationHistory = [];
        }
    }

    function saveToHistory() {
        calculationHistory.unshift(currentCalculation);
        
        // Keep only last 50 calculations
        if (calculationHistory.length > 50) {
            calculationHistory = calculationHistory.slice(0, 50);
        }
        
        try {
            localStorage.setItem('billSplitterHistory', JSON.stringify(calculationHistory));
        } catch (error) {
            console.error('Error saving to history:', error);
            showAlert('Unable to save to history', 'warning');
        }
    }

    // Show History Modal
    window.showHistory = function() {
        if (calculationHistory.length === 0) {
            showAlert('No calculation history yet. Make some calculations first!', 'info');
            return;
        }

        const historyHtml = calculationHistory.map((calc, index) => {
            const date = new Date(calc.timestamp).toLocaleDateString();
            const time = new Date(calc.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            const typeIcon = calc.type === 'itemized' ? '📋' : '💰';
            
            return `
                <div class="history-item" onclick="loadCalculation(${index})">
                    <div class="history-main">
                        ${typeIcon} <strong>${formatCurrency(calc.billAmount)}</strong> 
                        split ${calc.peopleCount} ways
                    </div>
                    <div class="history-details">
                        ${formatCurrency(calc.perPerson)} per person • ${calc.tipPercent}% tip
                        ${calc.items ? ` • ${calc.items.length} items` : ''}
                    </div>
                    <div class="history-date">
                        ${date} at ${time}
                    </div>
                </div>
            `;
        }).join('');

        const modalHtml = `
            <div class="modal-overlay" id="historyModal" onclick="closeHistoryIfOverlay(event)">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>📜 Recent Calculations</h3>
                        <button class="close-btn" onclick="closeHistory()">×</button>
                    </div>
                    <div class="history-list">
                        ${historyHtml}
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHtml);
    };

    // Load Calculation from History
    window.loadCalculation = function(index) {
        const calc = calculationHistory[index];
        
        if (calc.type === 'itemized') {
            // Switch to itemized mode
            if (!isAdvancedMode) {
                toggleCalculatorMode();
            }
            
            // Load itemized data
            itemizedItems = [...calc.items];
            itemizedTipInput.value = calc.tipPercent;
            itemizedPeopleInput.value = calc.peopleCount;
            updateItemizedList();
            
        } else {
            // Switch to basic mode
            if (isAdvancedMode) {
                toggleCalculatorMode();
            }
            
            // Load basic data
            billAmountInput.value = calc.billAmount;
            tipPercentInput.value = calc.tipPercent;
            peopleCountInput.value = calc.peopleCount;
        }
        
        // Load results
        currentCalculation = calc;
        displayResults();
        showResults();
        
        closeHistory();
        showAlert('Calculation loaded from history!', 'success');
    };

    // Close History Modal
    window.closeHistory = function() {
        const modal = document.getElementById('historyModal');
        if (modal) {
            modal.remove();
        }
    };

    // Close history if clicked on overlay
    window.closeHistoryIfOverlay = function(event) {
        if (event.target.classList.contains('modal-overlay')) {
            closeHistory();
        }
    };

    // Utility Functions
    function formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2
        }).format(amount);
    }

    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    function showAlert(message, type = 'info') {
        // Remove existing alerts
        const existingAlerts = document.querySelectorAll('.custom-alert');
        existingAlerts.forEach(alert => alert.remove());

        // Create alert element
        const alert = document.createElement('div');
        alert.className = `custom-alert alert-${type}`;
        alert.textContent = message;
        
        // Style the alert
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: ${getAlertColor(type)};
            color: white;
            padding: 12px 20px;
            border-radius: 25px;
            font-weight: bold;
            z-index: 10000;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            animation: alertSlideIn 0.3s ease;
            max-width: 90%;
            text-align: center;
        `;

        // Add CSS animation if not exists
        if (!document.querySelector('#alert-styles')) {
            const styles = document.createElement('style');
            styles.id = 'alert-styles';
            styles.textContent = `
                @keyframes alertSlideIn {
                    from { 
                        opacity: 0; 
                        transform: translateX(-50%) translateY(-20px); 
                    }
                    to { 
                        opacity: 1; 
                        transform: translateX(-50%) translateY(0); 
                    }
                }
                @keyframes alertSlideOut {
                    from { 
                        opacity: 1; 
                        transform: translateX(-50%) translateY(0); 
                    }
                    to { 
                        opacity: 0; 
                        transform: translateX(-50%) translateY(-20px); 
                    }
                }
            `;
            document.head.appendChild(styles);
        }

        document.body.appendChild(alert);

        // Auto-remove after 3 seconds
        setTimeout(() => {
            alert.style.animation = 'alertSlideOut 0.3s ease forwards';
            setTimeout(() => alert.remove(), 300);
        }, 3000);
    }

    function getAlertColor(type) {
        const colors = {
            success: '#4CAF50',
            error: '#f44336',
            warning: '#FF9800',
            info: '#2196F3'
        };
        return colors[type] || colors.info;
    }

    // Service Worker Registration for PWA
    if ('serviceWorker' in navigator) {
        window.addEventListener('load', function() {
            navigator.serviceWorker.register('/sw.js')
                .then(function(registration) {
                    console.log('SW registered: ', registration);
                })
                .catch(function(registrationError) {
                    console.log('SW registration failed: ', registrationError);
                });
        });
    }

    // Install App Prompt
    let deferredPrompt;
    
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        
        // Show install button/hint after user has used app a bit
        setTimeout(() => {
            showInstallHint();
        }, 30000); // Show after 30 seconds
    });

    function showInstallHint() {
        if (deferredPrompt && !localStorage.getItem('installHintShown')) {
            showAlert('💡 You can install this app for easier access!', 'info');
            localStorage.setItem('installHintShown', 'true');
            
            // Add install option to next ad rotation
            const installAd = {
                text: "📱 Install this app on your device!",
                action: "Tap here to install",
                color: "#9C27B0"
            };
            
            if (window.freeAds) {
                window.freeAds.push(installAd);
            }
        }
    }

    // Handle successful app installation
    window.addEventListener('appinstalled', (evt) => {
        showAlert('App installed successfully! 🎉', 'success');
        localStorage.setItem('appInstalled', 'true');
    });

    // Initialize the app
    init();

    // Export functions for global access
    window.billSplitterApp = {
        newCalculation,
        showHistory,
        toggleCalculatorMode,
        formatCurrency,
        showAlert
    };
});

// Additional utility functions that need to be globally accessible
window.addEventListener('load', function() {
    // Add keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + Enter to calculate
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            const calculateBtn = document.getElementById('calculateBtn');
            const calculateItemizedBtn = document.getElementById('calculateItemizedBtn');
            
            if (calculateBtn && calculateBtn.offsetParent !== null) {
                calculateBtn.click();
            } else if (calculateItemizedBtn && calculateItemizedBtn.offsetParent !== null) {
                calculateItemizedBtn.click();
            }
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            const modal = document.getElementById('historyModal');
            if (modal) {
                window.closeHistory();
            }
        }
    });

    // Handle offline/online status
    function updateOnlineStatus() {
        const isOnline = navigator.onLine;
        if (!isOnline) {
            window.billSplitterApp?.showAlert('App is offline but still functional!', 'info');
        }
    }

    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
});

// Performance optimization: Lazy load heavy features
if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Trigger any lazy-loaded content here
                console.log('Element in view:', entry.target);
            }
        });
    });

    // Observe elements that might need lazy loading
    document.addEventListener('DOMContentLoaded', () => {
        const lazyElements = document.querySelectorAll('.ad-banner');
        lazyElements.forEach(el => observer.observe(el));
    });
}